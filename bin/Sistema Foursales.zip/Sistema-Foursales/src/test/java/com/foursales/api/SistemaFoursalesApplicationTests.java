package com.foursales.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaFoursalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
